<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['templates_and_style'] = "模板和风格";

$l['themes'] = "主题";
$l['templates'] = "模板";

$l['can_manage_themes'] = "可以管理主题？";
$l['can_manage_templates'] = "可以管理模板？";

