<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['home'] = "主页";

$l['dashboard'] = "控制台";
$l['preferences'] = "偏好";
$l['mybb_credits'] = "MyBB名人堂";

$l['add_new_forum'] = "添加新论坛";
$l['search_for_users'] = "搜索用户";
$l['themes'] = "主题";
$l['templates'] = "模板";
$l['plugins'] = "插件";
$l['database_backups'] = "数据库备份";
$l['quick_access'] = "快速访问";
$l['online_admins'] = "在线管理员";
$l['ipaddress'] = "IP地址:";
$l['mybb_documentation'] = "MyBB文档";

