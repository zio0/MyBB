$(document).ready(function(){
	$(window).on('scroll', function(){
		if($(window).scrollTop() > $("#logo").height()) {
			$('#mypanel').addClass('fixed');	
			$('#wblockright').addClass('fixed2');
		}
			else {
				$('#mypanel').removeClass('fixed');
				$('#wblockright').removeClass('fixed2');
			}
	});
});