<?php
 /**
 * MyFlatBoard v3 Polish Language Pack
 *  Copyright © 2018 Filip 'SimLay' Cichorek
 **/


/** Zmiana Koloru **/
 $l['mfb3_changed_dark'] = "Zmieniono styl na ciemny";
 $l['mfb3_changed_light'] = "Zmieniono styl na jasny";
 $l['mfb3_change_color'] = "Zmień Kolor";

/** Menu **/
 $l['mfb3_memberlist'] = "Lista Użytkowników";
 $l['mfb3_search'] = "Szukaj";
 $l['mfb3_stats'] = "Statystyki";
 $l['mfb3_search_text'] = "Wyszukaj...";

/** Panel Usera **/
 $l['mfb3_welcome'] = "Posiadasz już konto?";
 $l['mfb3_login_button'] = "Zaloguj się";
 $l['mfb3_register_button'] = "Stwórz nowe konto";
 $l['mfb3_messeges'] = "Wiadomości";
 $l['mfb3_accountsetings_title'] = "Ustawienia konta";
 $l['mfb3_showprofile'] = "Zobacz swój profil";
 $l['mfb3_editprofile'] = "Edytuj profil";
 $l['mfb3_editsignature'] = "Edytuj sygnature";
 $l['mfb3_changepassword'] = "Zmień hasło";
 $l['mfb3_friendlist'] = "Lista znajomych";
 $l['mfb3_settings'] = "Ustawienia";
 $l['mfb3_content_title'] = "Zawartość";
 $l['mfb3_myattachments'] = "Moje załączniki";
 $l['mfb3_followedcontent'] = "Obserwowana zawartość";
 $l['mfb3_mycontent'] = "Moja zawartość";
 $l['mfb3_logout'] = "Wyloguj się";
 $l['mfb3_shouts'] = "wpisów";

/** Profil **/
 $l['mfb3_profile_status_online'] = "jest dostępny";
 $l['mfb3_profile_status_offline'] = "jest niedostępny";
 $l['mfb3_profile_send_pm'] = "Wyślij wiadomość";
 $l['mfb3_profile_posts'] = "Postów";
 $l['mfb3_profile_threads'] = "Tematów";
 $l['mfb3_profile_rep'] = "Reputacja";
 $l['mfb3_profile_regdate'] = "Data rejestracji";
 $l['mfb3_profile_bday'] = "Urodziny";
 $l['mfb3_profile_user_activity'] = "Aktywność użytkownika";
 $l['mfb3_profile_user_info'] = "Informacje";


/** Statstyki/Działy **/
 $l['mfb3_posts'] = "postów";
 $l['mfb3_threads'] = "tematów";
 $l['mfb3_replies'] = "odpowiedzi";
 $l['mfb3_views'] = "wyświetleń";
 $l['mfb3_users'] = "użytkowników";
 $l['mfb3_newestmember'] = "najnowszy użytkownik";
 $l['mfb3_profile_usergroup'] = "Grupa użytkownika:";

/** Stopka **/
 $l['mfb3_aboutus'] = "O nas";
 $l['mfb3_fastlinks'] = "Szybkie Linki";
 $l['mfb3_poweredby'] = "Forum napędza ";
 $l['mfb3_engine'] = "Silnik Forum";
 $l['mfb3_translation'] = " & <a href='https://mybboard.pl' target='_blank' rel='noopener' data-toggle='tooltip' title='Polskie Tłumaczenie'>MyBBoard.pl</a>";
 $l['mfb3_skinby'] = "Styl stworzony przez";
 $l['mfb3_simlayslogan'] = "Szablony MyBB dla ciebie!";
?>